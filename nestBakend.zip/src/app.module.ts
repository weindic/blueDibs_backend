import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { PrismaService } from './Prisma.Service';
import { APP_PIPE } from '@nestjs/core';
import { ZodValidationPipe } from 'nestjs-zod';
import { UserModule } from './user/user.module';
import { PassportModule } from '@nestjs/passport';
import { PostModule } from './post/post.module';
import { CommentModule } from './comment/comment.module';
import { HoldingModule } from './holdings/holdings.module';
import { WithdrawalModule } from './withdrawal/withdrawal.module';
import { PaymentmethodsModule } from './paymentmethods/paymentmethods.module';
import { AdminModule } from './admin/admin.module';
import { PlatformSellModule } from './platformsell/platformsell.module';
import { ReferralModule } from './referal/refral.module';
import { ReferralWalletModule } from './refralWallet/referral-wallet.module';
import { PopularProfileModule } from './blueTick/popular-profile.module';
import { VIPChatModule } from './vipChatSetting/vip-chat.module';
import { KycRequestModule } from './kycRequest/kyc-request.module';

@Module({
  imports: [
    PassportModule,
    UserModule,
    PostModule,
    CommentModule,
    HoldingModule,
    WithdrawalModule,
    PaymentmethodsModule,
    AdminModule,
    PlatformSellModule,
    ReferralWalletModule,
    ReferralModule,
    PopularProfileModule,
    VIPChatModule,
    KycRequestModule
  ],
  controllers: [AppController],
  providers: [
    AppService,
    PrismaService,
    {
      provide: APP_PIPE,
      useClass: ZodValidationPipe,
    },
  ],
})
export class AppModule {}
