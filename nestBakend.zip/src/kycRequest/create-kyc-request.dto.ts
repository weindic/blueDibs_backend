export class CreateKycRequestDto {
    userId: string;
    adhaarNumber: string;
    panNumber: string;
  }
  