import { Controller, Post, Body, Param, Patch, Get, UploadedFiles, UseInterceptors, BadRequestException, HttpStatus, HttpCode } from '@nestjs/common';
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { KycRequestService } from './kyc-request.service';
import { CreateKycRequestDto } from './create-kyc-request.dto';
import { UpdateKycStatusDto } from './update-kyc-status.dto';

@Controller('kyc-requests')
export class KycRequestController {
  constructor(private readonly kycRequestService: KycRequestService) {}

  @Post()
  @HttpCode(HttpStatus.OK)
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'adhaarImage', maxCount: 1 },
    { name: 'panImage', maxCount: 1 },
  ]))
  async create(
    @Body() createKycRequestDto: CreateKycRequestDto,
    @UploadedFiles() files: { adhaarImage?: Express.Multer.File[], panImage?: Express.Multer.File[] },
  ) {
    if (!files || !files.adhaarImage || !files.panImage) {
      throw new BadRequestException('Adhaar image and PAN image are required');
    }

    const adhaarImage = files.adhaarImage[0];
    const panImage = files.panImage[0];

    return this.kycRequestService.create(createKycRequestDto, adhaarImage.buffer.toString('base64'), panImage.buffer.toString('base64'));
  }

  @Patch(':id/status')
  @HttpCode(HttpStatus.OK)
  async updateStatus(@Param('id') id: string, @Body() updateKycStatusDto: UpdateKycStatusDto) {
    return this.kycRequestService.updateStatus(id, updateKycStatusDto);
  }

  @Get('user/:userId')
  @HttpCode(HttpStatus.OK)
  async findByUserId(@Param('userId') userId: string) {
    return this.kycRequestService.findByUserId(userId);
  }
}
