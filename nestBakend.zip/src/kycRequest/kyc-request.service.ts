import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from 'src/prisma.service';
import { CreateKycRequestDto } from './create-kyc-request.dto';
import { UpdateKycStatusDto } from './update-kyc-status.dto';

@Injectable()
export class KycRequestService {
  constructor(private prisma: PrismaService) {}

  async create(createKycRequestDto: CreateKycRequestDto, adhaar: string, pan: string) {
    console.log(pan, adhaar);

    return this.prisma.kycRequest.create({
      data: {
        ...createKycRequestDto,
        adhaar,
        pan,
      },
    });
  }

  async updateStatus(id: string, updateKycStatusDto: UpdateKycStatusDto) {
    const kycRequest = await this.prisma.kycRequest.findUnique({ where: { id } });
    if (!kycRequest) {
      throw new NotFoundException('KYC Request not found');
    }

    return this.prisma.kycRequest.update({
      where: { id },
      data: { status: updateKycStatusDto.status },
    });
  }

  async findByUserId(userId: string) {
    return this.prisma.kycRequest.findUnique({ where: { userId } });
  }
}
