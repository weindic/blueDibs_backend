export class UpdateKycStatusDto {
    status: number;
  }
  