import { Module } from "@nestjs/common";
import { EmailService } from "./email.service";
import { PrismaService } from "src/Prisma.Service";
import { MailerModule } from '@nestjs-modules/mailer';
import { join } from "path";
import { HandlebarsAdapter } from '@nestjs-modules/mailer/dist/adapters/handlebars.adapter';

@Module({
    imports: [MailerModule.forRoot({
        transport: {
          host: 'smtp-relay.brevo.com',
          secure: false,
          auth: {
            user: 'sharpprogrammer2018@gmail.com',
            pass: 'h0dfp3GtyUIV7ma1',
          },
        },
        defaults: {
          from: '"No Reply" <noreply@example.com>',
        },
        template: {
          dir: join(__dirname, '..' ,'templates'),
          adapter: new HandlebarsAdapter(),
          options: {
            strict: true,
          },
        },
      }),
    ],
    providers: [EmailService, PrismaService],
    exports: [EmailService]
})
export class EmailModule {}