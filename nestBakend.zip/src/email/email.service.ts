import { MailerService } from '@nestjs-modules/mailer';
import { Injectable } from '@nestjs/common';

@Injectable()
export class EmailService {
  constructor(private mailerService: MailerService) {}

  async sendOtpEmail(email: string, otp: string) {
   let dt = await this.mailerService.sendMail({
      to: email.toLocaleLowerCase(),
      from: '"Support Team" <admin@bluedibs.com>',
      subject: 'Welcome to BlueDibs! Confirm your Email',
      template: './confirmation',
      context: {
        otp,
      },
    });


    console.log(dt)
  }
}
