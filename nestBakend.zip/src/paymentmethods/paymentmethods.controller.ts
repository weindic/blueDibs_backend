import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Req,
  UnauthorizedException,
} from '@nestjs/common';
import { PrismaService } from 'src/Prisma.Service';
import { UpdatePaymentmethodDto } from './paymentmethods.dto';

@Controller('paymentmethods')
export class PaymentmethodsController {
  constructor(private readonly pService: PrismaService) {}

  @Get()
  findOne(@Req() req) {
    return this.pService.paymentMethod.findFirst({
      where: {
        User: {
          id: req.user.id,
        },
      },
    });
  }

  @Patch()
  async update(
    @Body() updatePaymentmethodDto: UpdatePaymentmethodDto,
    @Req() req,
  ) {
    // REFACTOR: make this user extraction to middleware level

    console.log(req);

    // or add a claim to the token holding user id
    const user = await this.pService.user.findFirst({
      where: {
        id: req.user.id,
      },
    });

    if (!user) throw new UnauthorizedException('user not found');

    return this.pService.paymentMethod.upsert({
      where: {
        userId: user.id,
      },
      update: {
        upiId: updatePaymentmethodDto.upiId,
      },
      create: {
        upiId: updatePaymentmethodDto.upiId,
        userId: user.id,
      },
    });
  }
}
