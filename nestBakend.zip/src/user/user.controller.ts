import {
  Controller,
  Param,
  Get,
  HttpException,
  HttpStatus,
  Post,
  Body,
  Patch,
  HttpCode,
  Req,
  UseInterceptors,
  UploadedFile,
  UnauthorizedException,
  BadRequestException,
  UseGuards,
  Put,
} from '@nestjs/common';
import { PrismaService } from 'src/Prisma.Service';
import {
  AddFundDTO,
  AddUserDTO,
  MultipleProfilesDTO,
  OtpSendDTO,
  OtpVerifyDRO,
  SellOwnEquity,
  UpdateUserDTO,
  UpdateUserPersonalInfoDTO,
  UserSetupDTO,

} from './user.DTOs';
import { FileInterceptor } from '@nestjs/platform-express';
import { app, bucket } from 'src/firebase';
import { SaveOptions } from '@google-cloud/storage';
import type { Holding, Post as MediaPost } from '@prisma/client';
import { HoldingService } from 'src/holdings/holdings.service';
import { UserService } from './UserService';
import { EmailService } from 'src/email/email.service';
import crypto from 'crypto';
import * as dayjs from 'dayjs';
import * as duration from 'dayjs/plugin/duration';
import { ObjectId } from 'bson';
import { Request } from 'express';
dayjs.extend(duration);

@Controller('user')
export class UserController {
  constructor(
    private readonly pService: PrismaService,
    private readonly holdingService: HoldingService,
    private readonly userService: UserService,
  ) {}

  // Other existing methods...


  // @Get('dummy')
  // async dummyEndpoint() {
  //   return {
  //     statusCode: 200,
  //     message: 'Dummy API working successfully!',
  //     data: {
  //       example: 'Sample data for testing purposes',
  //     },
  //   };
  // }


  @Post('update-profile')
  @HttpCode(HttpStatus.OK)
  @UseInterceptors(FileInterceptor('avatar'))

  async updateProfileAndAvatar(
    @Req() req,
    @Body() body: UpdateUserDTO,
    @UploadedFile() avatar: Express.Multer.File
  ) {
    // Extract user data from request body
    const firebaseId = body.id;
    
    if (!firebaseId) {
      throw new BadRequestException('Firebase ID is required');
    }
    

   
    // Find user by Firebase ID
    const user = await  this.userService.findUserByFirebaseId(firebaseId)
    
    
  

    console.log(firebaseId, user)
    
    // Check if the user exists
    if (!user) {
      throw new BadRequestException('User does not exist');
    }
    
    // Extract user ID from the found user
    const userId = user.id;
    
    // Ensure the user ID is valid
    if (!userId) {
      throw new BadRequestException('User ID is required');
    }
  
    // Prepare data for updating user profile
    let updatedUserData = {
      dob: body.dob,
      mobile: body.mobile?.toString(),
      gender: body.gender,
      bio: body.bio,
      avatarPath: body.avatarPath,
    };
    
    // Handle avatar file upload if provided
    if (avatar) {
      console.log('Avatar change detected, uploading profile pic');
      
      // Create a unique filename for the avatar
      const filename = `${avatar.originalname.split('.')[0]}_${Date.now()}.${avatar.originalname.split('.').pop()}`;
      
      // Reference to the Firebase Storage file
      const fileRef = bucket.file(filename);
      
      // Upload the avatar file to Firebase Storage
      await fileRef.save(avatar.buffer, {
        contentType: avatar.mimetype,
        cacheControl: 'public, max-age=31536000', // Set cache control as needed
      } as SaveOptions);
      
      // Set the avatarPath in updatedUserData
      updatedUserData.avatarPath = filename;
    }
  
    // If avatar was included in the body, remove it to avoid conflicts
    if (body.avatar) {
      delete body.avatar;
    }
  
    // Delegate the update request to userService.updateUserProfile
    const updatedUser = await this.userService.updateUserProfile(userId, updatedUserData);
  
    // Return the updated user data
    return {
      status: HttpStatus.OK,
      message: 'Profile updated successfully',
      data: updatedUser,
    };
  }



  // @Patch('update-profile')
  // @HttpCode(HttpStatus.OK)
  // async updateProfile(
  //     @Req() request: Request,
  //     @Body() body: UpdateUserDTO,
  // ) {
  //     const firebaseId = body.id;
  
  //     // Ensure the firebaseId is retrieved from the request

  //     if (!firebaseId) {
  //         throw new BadRequestException('Firebase ID is required');
  //     }

  //     const user = await this.pService.user.findFirst({
  //       where: {
  //         firebaseId:  firebaseId,
  //         activated: false
        
  //       },
  //     });
   
  
  //     // Check if user exists
  //     if (!user) {
  //         throw new BadRequestException('check'+user);
  //     }
  
  //     // Extract _id from the user data
  //     const userId = user.id;
  
  //     // Ensure the user ID is valid
  //     if (!userId) {
  //         throw new BadRequestException('User ID is required');
  //     }
      

  //     const bodyData = {
  //       dob: body.dob,
  //       mobile:body.mobile?.toString(),
  //       gender: body.gender,
  //       bio: body.bio,
  //       avatar: body.avatar,
  //     }
  

  //     console.log('jhhhhhhhhhhhh j',bodyData)
  //     // Delegate the request to the service
  //     return this.userService.updateUserProfile(userId.toString(), bodyData);
  // }
  

  @Post('verify-otp')
  @HttpCode(HttpStatus.OK)
  async verifyOtp(@Body() body: OtpVerifyDRO) {
    const user = await this.pService.user.findFirst({
      where: {
        email: body.email,
        activated: false,
      },
    });

    if (!user) throw new UnauthorizedException('user not found');
    if (
      user.otpSentTime &&
      dayjs.duration(user.otpSentTime.getUTCMilliseconds()).asMinutes() > 5
    )
      throw new BadRequestException('otp expired');

    if (+body.otp == user.otp) {
      // means the user is verified
      await app.auth().updateUser(user.firebaseId, { emailVerified: true });
      return this.pService.user.update({
        where: {
          id: user.id,
        },
        data: {
          verified: true,
        },
      });
    }
    throw new BadRequestException('OTP Verification failed');
  }

  @Post('send-otp')
  @HttpCode(HttpStatus.OK)
  async sendVerificationotp(@Body() body: OtpSendDTO) {
    const user = await this.pService.user.findFirst({
      where: {
        email: body.email,
        activated: false,
      },
    });

    if (!user) throw new BadRequestException('user not found');
    if (
      user.otpSentTime &&
      dayjs
        .duration(user.otpSentTime.getUTCMilliseconds(), 'seconds')
        .asSeconds() < 10
    )
      throw new BadRequestException('cannot send another otp under 10 seconds');

    return this.userService.sendOTpEmail(body.email);
  }

  @Get('wallet')
  async getUserFinancialInfo(@Req() req) {
    // get holdings
    const holdings = await this.holdingService.getUserHoldings(req.user.id);

    // get user profile for calculating stats
    const stats = await this.pService.user.findFirst({
      where: {
        id: req.user.id,
      },
    });

    // TODO : change 1 to the value
    // calculate total investment
    let ttlInvestment = 0;
    let ttlReturns = 0;

    for (const holding of holdings) {
      ttlInvestment += holding.investedInr;
      ttlReturns += holding.amount * holding.sellerUser.price;
    }

    const tiiys = await this.pService.holding.findMany({
      where: {
        sellerUser: {
          id: req.user.id,
        },
      },
      include: {
        buyerUser: {
          select: {
            username: true,
          },
        },
        sellerUser: {
          select: {
            price: true,
          },
        },
      },
    });

    if (ttlInvestment < 1) ttlInvestment = 0;

    return {
      holdings,
      ttlInvestment: ttlInvestment,
      ttlReturns: ttlReturns - ttlInvestment,
      balance: stats?.balance,
      tiiys,
    };
  }

  @Get('username/:username')
  getUser(@Param('username') username) {
    return this.pService.user.findFirst({
      where: {
        username: username,
      },
    });
  }

  @Post('like/:id')
  async likePost(@Param('id') id, @Req() req) {
    await this.pService.user.update({
      where: {
        id: req.user.id,
      },
      data: {
        PostsLiked: {
          connect: {
            id: id,
          },
        },
      },
    });

    return id;
  }

  @Post('unLike/:id')
  async dislikePOst(@Param('id') id, @Req() req) {
    await this.pService.user.update({
      where: {
        id: req.user.id,
      },
      data: {
        PostsLiked: {
          disconnect: {
            id: id,
          },
        },
      },
    });
    return id;
  }

  // feeds algorithim
  @Get('feed')
  async getUserFeeds(@Req() req) {
    const page = parseInt(req.query.page) ?? 0;
    const perPage = 10;

    const user = await this.pService.user.findFirst({
      where: {
        id: req.user.id,
      },

      select: {
        following: {
          select: {
            id: true,
          },
        },
      },
    });

    const followingUserIds = (user?.following ?? []).map((fUser) => fUser.id);

    const posts = await this.pService.post.findMany({
      where: {
        userId: {
          in: followingUserIds,
        },
      },

      orderBy: {
        created: 'desc',
      },

      take: perPage,
      skip: page * perPage,

      include: {
        User: {
          select: {
            username: true,
            avatarPath: true,
            id: true,
            price: true,
          },
        },
      },
    });

    return {
      page,
      perPage,
      total: await this.pService.post.count({
        where: {
          userId: { in: followingUserIds },
        },
      }),
      posts,
    };
  }

  @Post('follow/:id')
  async followUser(@Param('id') id, @Req() req) {
    return this.pService.user.update({
      where: {
        id: req.user.id,
      },
      data: {
        following: {
          connect: {
            id: id,
          },
        },
      },
    });
  }

  @Post('unfollow/:id')
  unfollowUser(@Param('id') id, @Req() req) {
    return this.pService.user.update({
      where: {
        id: req.user.id,
      },
      data: {
        following: {
          disconnect: {
            id: id,
          },
        },
      },
    });
  }

  @Post('profiles')
  async getMultipleUserProfile(@Body() profiles: MultipleProfilesDTO) {
    const data = await this.pService.user.findMany({
      where: {
        id: { in: profiles },
      },
      select: {
        id: true,
        username: true,
        avatarPath: true,
      },
    });

    return data;
  }

  @Get()
  async getUserId(@Req() req) {
    const user = await this.pService.user.findFirst({
      where: {
        id: req.user.id,
      },
      include: {
        PaymentMethod: true,
      },
    });

    if (!user)
      throw new HttpException('user not found', HttpStatus.UNAUTHORIZED);

    const wallet_vars = await this.userService.getSelfOwnEquiryVars(user);

    const INRLocked = (
      await this.pService.holding.findMany({
        where: {
          seller_id: user.id,
        },
      })
    ).reduce((acc, curr) => acc + curr.amount * user.price, 0);

    // generate and send it's graph data
    const userTxns = await this.pService.transaction.findMany({
      where: {
        seller_id: user.id,
      },
      orderBy: {
        created: 'asc',
      },
      take: 10,
    });

    const graphData = this.userService.generateGraphData(userTxns);

    return {
      ...user,
      INRLocked: INRLocked,
      ...wallet_vars,
      platformEquity: user.platformEquity,
      posts: await this.pService.post.count({ where: { userId: user.id } }),
      graphData,
    };
  }

  @Post()
  @HttpCode(HttpStatus.OK)
  async addUser(@Body() body: AddUserDTO) {
    const username = await this.pService.user.count({
      where: {
        username: body.username,
        activated: true,
      },
    });

    if (username > 0)
      throw new HttpException('username already exsists', HttpStatus.CONFLICT);

    try {
      const otp = this.userService.generateOTP(4);

      const user = await this.pService.user.upsert({
        create: {
          email: body.email,
          username: body.username,
          firebaseId: body.firebaseId,
          shares: 0,
          lastSell: { equity: 0, time: new Date(0) },
          otp: +otp,
          otpSentTime: new Date(),
        },
        where: {
          activated: false,
          email: body.email,
        },
        update: {
          email: body.email,
          firebaseId: body.firebaseId,
          shares: 0,
          lastSell: { equity: 0, time: new Date(0) },
          otp: +otp,
          otpSentTime: new Date(),
        },
      });
      await this.userService.sendOTpEmail(user.email, otp);
    } catch (err) {
      console.log(err);
      if (err.code == 'P2002') {
        throw new HttpException('User already exsists', HttpStatus.CONFLICT);
      } else
        throw new HttpException(
          'Something went wrong',
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
    }
  }

  @Post('setup')
  async setUp(@Body() body: UserSetupDTO, @Req() req) {
    return this.pService.user.update({
      where: {
        id: req.user.id,
      },
      data: {
        shares: body.shares_dilute,
        userEquity: body.equity_shares,
        activated: true,
      },
    });
  }

  @Get('search/:name')
  searchUserByName(@Param('name') name, @Req() req) {
    return this.pService.user.findMany({
      where: {
        username: {
          contains: name,
          mode: 'insensitive',
        },

        id: {
          not: req.user.id,
        },
      },
    });
  }

  @Get('feeds/:username')
  async getUserByUsername(@Param('username') username, @Req() req) {
    const page = parseInt(req.query.page) ?? 0;
    const perPage = 10;

    const posts = await this.pService.post.findMany({
      where: {
        User: {
          username: username,
        },
      },
      include: {
        User: true,
      },

      skip: page * perPage,
      take: perPage,

      orderBy: {
        created: 'desc',
      },
    });

    return {
      page,
      perPage,
      total: await this.pService.post.count({
        where: {
          User: { username },
        },
      }),
      posts,
    };
  }

  @Post('sell-own-equity')
  @HttpCode(HttpStatus.OK)
  async sellOwnEquity(@Req() req, @Body() body: SellOwnEquity) {
    await this.userService.sellPlatformEquity(req.user.id, body.percentage);

    return 'Sold';
  }


  @Get('suggestions/users')
  async getSuggetedUsers(@Req() req) {
    return this.pService.user
      .findMany({
        where: {
          activated: true,
          NOT: {
            followers: {
              some: { id: req.user.id },
            },
          },
        },

        take: 10,
        orderBy: { Posts: { _count: 'desc' } },
      })
      .then((users) =>
        users.filter(
          (user) =>
            ![
              '657b12dfe1040ebf6d05e6d7',
              req.user.id,
              '657b14c8e1040ebf6d05e6d9',
            ].includes(user.id),
        ),
      );
  }

  @Get('suggestions/pinned')
  async getPinnedUsers(@Req() req) {
    return this.pService.user.findMany({
      where: {
        firebaseId: {
          in: ['5fteNgu0H6Smy8khVlHlLQLNhuF2', 'UJ2XlRbfOJdpccwoDHInbtCzoGs2'],
        },
      },
    });
  }

  @Get('followers/:username')
  async getFollowers(@Param('username') username: string, @Req() req) {
    return this.userService.getFollowerOrFollowings(username, {
      page: parseInt(req.query.page) ?? 0,
      type: 'followers',
    });
  }

  @Get('following/:username')
  async getFollowing(@Param('username') username: string, @Req() req) {
    return this.userService.getFollowerOrFollowings(username, {
      page: parseInt(req.query.page) ?? 0,
      type: 'following',
    });
  }

  @Post('add-fund')
  @HttpCode(HttpStatus.OK)
  async addFundRequest(@Req() req, @Body() body: AddFundDTO) {
    return this.userService.addFundReq(req.user.id, body);
  }

  @Patch('add-fund')
  @HttpCode(HttpStatus.OK)
  async updateFundStatus(@Req() req, @Body() body: AddFundDTO) {
    return this.userService.addFundReq(req.user.id, body);
  }

  @Post('personal-information')
  @HttpCode(HttpStatus.OK)
  async setUserPersonalInformation(
    @Req() req,
    @Body() body: UpdateUserPersonalInfoDTO,
  ) {
    await this.userService.updateUserInfo(req.user.id, body);
  }

  @Get(':id')
  async getPublicUser(@Param('id') id) {
    const user = await this.pService.user.findFirst({
      where: {
        id: id,
      },
      include: {
        Sold: true,
      },
    });

    if (!user) throw new HttpException('User not found', HttpStatus.NOT_FOUND);

    const sharesAmountSold = user?.Sold.reduce(
      (prev: any, cur) => {
        prev?.amount ?? 0 + cur?.amount ?? 0;
      },
      { amount: 0 },
    );

    if (!user) throw new HttpException('User not found', HttpStatus.NOT_FOUND);

    // generate and send it's graph data
    const userTxns = await this.pService.transaction.findMany({
      where: {
        seller_id: user.id,
      },
      orderBy: {
        created: 'asc',
      },
      take: 10,
    });

    const graphData = this.userService.generateGraphData(userTxns);

    // TODO
    const INRLocked = (
      await this.pService.holding.findMany({
        where: {
          seller_id: user.id,
        },
      })
    ).reduce((acc, curr) => acc + curr.investedInr, 0);

    return {
      sold: sharesAmountSold,
      ...user,
      userTxns,
      graphData,
      INRLocked: INRLocked,
      posts: await this.pService.post.count({ where: { userId: user.id } }),
    };
  }
}
