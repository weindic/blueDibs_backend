export class AssignBlueTickDTO {
    userId: string;
    status: number;
  }
  