import { Controller, Post, Body, Get, Param } from '@nestjs/common';
import { ReferralWalletService } from './referral-wallet.service';
import { CreateReferralWalletDTO } from './referral-wallet.dto';

@Controller('referral-wallets')
export class ReferralWalletController {
  constructor(private readonly referralWalletService: ReferralWalletService) {}

  @Post()
  async create(@Body() createReferralWalletDto: CreateReferralWalletDTO) {
    return this.referralWalletService.createReferralWallet(createReferralWalletDto);
  }

  @Get(':userId')
  async getWalletBalance(@Param('userId') userId: string) {
    const balance = await this.referralWalletService.getWalletBalance(userId);
    return { userId, balance };
  }
}
